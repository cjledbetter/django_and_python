from django.contrib import admin
from approvals.models import Approval

admin.site.register(Approval)
